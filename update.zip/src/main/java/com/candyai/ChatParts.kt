package com.candyai

import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.semantics.Role
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Button
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.foundation.layout.statusBarsPadding
import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import android.text.format.DateUtils
import android.util.Base64
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.vector.rememberVectorPainter
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.coerceIn
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.io.File
import kotlin.random.Random
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

internal fun aiDayLabel(ctx: Context, t: Long): String = when {
    DateUtils.isToday(t) -> ctx.getString(R.string.chat_today)
    DateUtils.isToday(t + DateUtils.DAY_IN_MILLIS) -> ctx.getString(R.string.chat_yesterday)
    else -> DateUtils.formatDateTime(ctx, t, DateUtils.FORMAT_SHOW_DATE or DateUtils.FORMAT_SHOW_YEAR)
}

internal fun sameDay(a: Long, b: Long): Boolean {
    val day = DateUtils.DAY_IN_MILLIS
    val tz = java.util.TimeZone.getDefault()
    return (a + tz.getOffset(a)) / day == (b + tz.getOffset(b)) / day
}


@Composable
internal fun AiTypingBubble(label: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Start, verticalAlignment = Alignment.Bottom) {
        AiAvatar(32.dp)
        Spacer(Modifier.size(8.dp))
        Surface(
            shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp, bottomEnd = 20.dp, bottomStart = 6.dp),
            color = MaterialTheme.colorScheme.surfaceContainerHigh,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        ) {
            Row(
                Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                TypingDots()
                Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

/** What Candy is doing right now, next to the menu button. Screen readers announce it when it changes. */
@Composable
internal fun StatusChip(pose: StagePose) {
    val cs = MaterialTheme.colorScheme
    val candy = LocalCandy.current
    val text = stringResource(
        when (pose) {
            StagePose.Idle -> R.string.ai_status_idle
            StagePose.Listening -> R.string.ai_status_listen
            StagePose.Thinking -> R.string.ai_status_think
            StagePose.Searching -> R.string.ai_status_search
            StagePose.Success -> R.string.ai_status_done
            StagePose.Sorry -> R.string.ai_status_sorry
        },
    )
    val dot = when (pose) {
        StagePose.Idle, StagePose.Success -> Color(0xFF2E9E5B)
        StagePose.Sorry -> cs.error
        else -> candy.cta
    }
    Surface(
        shape = CircleShape,
        color = cs.background.copy(alpha = 0.88f),
        modifier = Modifier.semantics { liveRegion = LiveRegionMode.Polite },
    ) {
        Row(
            Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Box(Modifier.size(8.dp).clip(CircleShape).background(dot))
            Text(text, color = cs.onBackground, style = MaterialTheme.typography.labelMedium, maxLines = 1)
        }
    }
}

/** Three dots that fade in turn while Candy writes. Still (not animated) when the phone has animations switched off. */
@Composable
private fun TypingDots() {
    val dot = LocalCandy.current.cta
    val animate = remember { android.animation.ValueAnimator.areAnimatorsEnabled() }
    val t = rememberInfiniteTransition(label = "typing")
    Row(horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically) {
        for (i in 0..2) {
            val a by t.animateFloat(
                initialValue = 0.25f,
                targetValue = 1f,
                animationSpec = infiniteRepeatable(tween(600, delayMillis = i * 200), RepeatMode.Reverse),
                label = "dot$i",
            )
            Box(Modifier.size(7.dp).clip(CircleShape).graphicsLayer { alpha = if (animate) a else 0.7f }.background(dot))
        }
    }
}

@Composable
internal fun AiBubble(m: AiMsg) {
    val big = 20.dp
    val small = 6.dp
    val cs = MaterialTheme.colorScheme
    val candy = LocalCandy.current
    val mineShape = RoundedCornerShape(topStart = big, topEnd = big, bottomEnd = small, bottomStart = big)
    val aiShape = RoundedCornerShape(topStart = big, topEnd = big, bottomEnd = big, bottomStart = small)
    BoxWithConstraints(Modifier.fillMaxWidth()) {
        // a bubble takes at most 82% of the width, so it also fits small phones and tablets (it was a fixed 300dp)
        val cap = maxWidth * CandyDims.bubbleFraction
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = if (m.mine) Arrangement.End else Arrangement.Start,
            verticalAlignment = Alignment.Bottom,
        ) {
            if (!m.mine) {
                AiAvatar(32.dp)
                Spacer(Modifier.size(8.dp))
            }
            if (m.mine) {
                Box(
                    Modifier
                        .widthIn(max = cap)
                        .clip(mineShape)
                        .background(candy.userBubble)
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp), horizontalAlignment = Alignment.End) {
                        for (a in m.atts) AttachView(a)
                        if (m.text.isNotBlank()) Text(m.text, color = candy.onUserBubble, style = MaterialTheme.typography.bodyLarge)
                    }
                }
            } else {
                Box(
                    Modifier
                        .widthIn(max = cap)
                        .clip(aiShape)
                        .background(cs.surfaceContainerHigh)
                        .border(1.dp, cs.outlineVariant, aiShape)
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        for (a in m.atts) AttachView(a, large = true)
                        if (m.text.isNotBlank()) SelectionContainer {
                            AiMarkdown(m.text)
                        }
                    }
                }
            }
        }
    }
}

@Composable
internal fun MemChip(label: String, onClick: () -> Unit) {
    Surface(
        shape = CircleShape,
        color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.65f),
        modifier = Modifier.clip(CircleShape).clickable(onClick = onClick),
    ) {
        Text(
            label,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSecondaryContainer,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
        )
    }
}

internal fun aiPlain(text: String): String = stripArtifacts(text).replace("**", "").trim()

internal fun copyAiText(ctx: Context, text: String) {
    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager ?: return
    cm.setPrimaryClip(ClipData.newPlainText("Candy", aiPlain(text)))
    // Android 13 and newer show their own "copied" note
    if (Build.VERSION.SDK_INT < 33) Toast.makeText(ctx, R.string.ai_copied, Toast.LENGTH_SHORT).show()
}

@Composable
internal fun AiActionIcon(painter: Painter, description: Int, active: Boolean, flip: Boolean = false, size: Dp = 17.dp, onClick: () -> Unit) {
    Box(
        Modifier.size(CandyDims.tap).clip(CircleShape).clickable(role = androidx.compose.ui.semantics.Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            painter,
            contentDescription = stringResource(description),
            tint = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(size).graphicsLayer { scaleY = if (flip) -1f else 1f },
        )
    }
}

/** Under each of Candy's replies: listen (Pro and Elite), copy, like, share, and "more" (dislike, and answer again on the last one). */
@Composable
internal fun AiActionRow(
    voice: Boolean,
    playing: Boolean,
    loading: Boolean,
    onVoice: () -> Unit,
    react: Int,
    onLike: () -> Unit,
    onDislike: () -> Unit,
    onCopy: () -> Unit,
    onShare: () -> Unit,
    onResend: (() -> Unit)?,
) {
    var more by remember { mutableStateOf(false) }
    Row(
        Modifier.fillMaxWidth().padding(start = 40.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (voice) {
            if (playing) {
                AiActionIcon(rememberVectorPainter(Icons.Rounded.Stop), R.string.ai_voice_stop, true, size = 22.dp, onClick = onVoice)
            } else {
                AiActionIcon(painterResource(R.drawable.ic_ear), R.string.ai_voice_play, false, onClick = { if (!loading) onVoice() })
            }
        }
        AiActionIcon(painterResource(R.drawable.ic_copy), R.string.ai_act_copy, false, onClick = onCopy)
        AiActionIcon(painterResource(R.drawable.ic_like), R.string.ai_act_like, react == 1, onClick = onLike)
        AiActionIcon(painterResource(R.drawable.ic_share), R.string.ai_act_share, false, onClick = onShare)
        Box {
            // tinted while a dislike is set, so the state is not hidden inside the menu
            AiActionIcon(rememberVectorPainter(Icons.Rounded.MoreVert), R.string.ai_act_more, react == -1, size = 22.dp, onClick = { more = true })
            DropdownMenu(expanded = more, onDismissRequest = { more = false }) {
                DropdownMenuItem(
                    text = { Text(stringResource(R.string.ai_act_dislike)) },
                    leadingIcon = { Icon(painterResource(R.drawable.ic_like), contentDescription = null, modifier = Modifier.size(18.dp).graphicsLayer { scaleY = -1f }) },
                    onClick = { more = false; onDislike() },
                )
                if (onResend != null) {
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.ai_act_resend)) },
                        leadingIcon = { Icon(painterResource(R.drawable.ic_resend), contentDescription = null, modifier = Modifier.size(18.dp)) },
                        onClick = { more = false; onResend() },
                    )
                }
            }
        }
    }
}

/** "Saved to memory: ..." under the reply that changed Candy's memory. */
@Composable
internal fun AiMemChips(m: AiMsg, onClick: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(start = 40.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        for (t in m.memAdded) MemChip("🧠 " + stringResource(R.string.ai_mem_saved, t), onClick)
        for (t in m.memRemoved) MemChip("🧠 " + stringResource(R.string.ai_mem_removed, t), onClick)
    }
}

@Composable
internal fun AiDayChip(label: String) {
    Box(Modifier.fillMaxWidth().padding(vertical = 6.dp), contentAlignment = Alignment.Center) {
        Surface(shape = CircleShape, color = MaterialTheme.colorScheme.surfaceContainerHigh) {
            Text(
                label,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
            )
        }
    }
}


/** What Candy is doing while she researches: the finished steps with a tick, and the current one with a spinner. */
@Composable
internal fun ResearchCard(steps: List<String>) {
    val c = MaterialTheme.colorScheme
    androidx.compose.material3.Surface(
        shape = RoundedCornerShape(18.dp),
        color = c.secondaryContainer.copy(alpha = 0.65f),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(horizontal = 14.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("🔎 " + stringResource(R.string.research_title), style = MaterialTheme.typography.labelLarge, color = c.onSecondaryContainer, fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold)
            steps.forEachIndexed { i, s ->
                val last = i == steps.lastIndex
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (last) androidx.compose.material3.CircularProgressIndicator(Modifier.size(14.dp), strokeWidth = 2.dp, color = c.onSecondaryContainer)
                    else Text("✓", style = MaterialTheme.typography.labelMedium, color = c.onSecondaryContainer.copy(alpha = 0.6f))
                    Text(
                        s, style = MaterialTheme.typography.labelMedium,
                        color = c.onSecondaryContainer.copy(alpha = if (last) 1f else 0.6f),
                        maxLines = 1, overflow = TextOverflow.Ellipsis,
                    )
                }
            }
        }
    }
}

/** A message that never reached the server: it stays in the chat, marked, with a button to send it again. */
internal class FailedSend(val text: String, val files: List<Pending>, val reason: String)

@Composable
internal fun FailedBubble(text: String, reason: String, onResend: () -> Unit, onEdit: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val candy = LocalCandy.current
    val shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp, bottomEnd = 6.dp, bottomStart = 20.dp)
    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val cap = maxWidth * CandyDims.bubbleFraction
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Box(
                Modifier.widthIn(max = cap).clip(shape).background(cs.surfaceContainerHigh)
                    .border(1.5.dp, cs.error, shape).padding(horizontal = 14.dp, vertical = 10.dp),
            ) { Text(text, color = cs.onSurface, style = MaterialTheme.typography.bodyLarge) }
            Row(Modifier.widthIn(max = cap), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Icon(Icons.Rounded.Warning, contentDescription = null, tint = cs.error, modifier = Modifier.size(16.dp))
                Text(stringResource(R.string.msg_not_sent) + " · " + reason, color = cs.error, style = MaterialTheme.typography.labelMedium)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = onResend,
                    colors = ButtonDefaults.buttonColors(containerColor = candy.cta, contentColor = candy.onCta),
                    modifier = Modifier.heightIn(min = 44.dp),
                ) { Text(stringResource(R.string.msg_resend)) }
                OutlinedButton(
                    onClick = onEdit,
                    border = BorderStroke(1.dp, cs.outlineVariant),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = cs.onSurface),
                    modifier = Modifier.heightIn(min = 44.dp),
                ) { Text(stringResource(R.string.msg_edit)) }
            }
        }
    }
}

/** A problem that needs the reader's attention: a card, with "try again" only when trying again can help. */
@Composable
internal fun ErrorCard(message: String, onRetry: (() -> Unit)?, onDismiss: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val candy = LocalCandy.current
    val dark = cs.background.luminance() < 0.5f
    val accent = if (onRetry != null) cs.error else if (dark) Color(0xFFFFD166) else Color(0xFFC77700)
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = candy.surface,
        border = BorderStroke(1.dp, candy.border),
        modifier = Modifier.fillMaxWidth().semantics { liveRegion = LiveRegionMode.Polite },
    ) {
        Row(Modifier.height(IntrinsicSize.Min)) {
            Box(Modifier.width(4.dp).fillMaxHeight().background(accent))
            Column(Modifier.weight(1f).padding(start = 12.dp, top = 12.dp, bottom = 12.dp)) {
                Text(message, color = candy.text, style = MaterialTheme.typography.bodyMedium)
                if (onRetry != null) {
                    Spacer(Modifier.height(8.dp))
                    Button(
                        onClick = onRetry,
                        colors = ButtonDefaults.buttonColors(containerColor = candy.cta, contentColor = candy.onCta),
                        modifier = Modifier.heightIn(min = 44.dp),
                    ) { Text(stringResource(R.string.retry)) }
                }
            }
            AppIconButton(Icons.Rounded.Close, stringResource(R.string.msg_dismiss), onDismiss, tint = candy.subtext)
        }
    }
}

/** A small note that goes away by itself (a file that cannot be read, a recording that was too short...). */
@Composable
internal fun NoteSnack(text: String, onDismiss: () -> Unit, modifier: Modifier = Modifier) {
    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val bg = if (dark) Color(0xFFF3EAFB) else Color(0xFF2B1B20)
    val fg = if (dark) Color(0xFF210B2C) else Color.White
    val act = if (dark) Color(0xFFC93A5E) else Color(0xFFFFD166)
    Surface(shape = RoundedCornerShape(12.dp), color = bg, shadowElevation = 6.dp, modifier = modifier.fillMaxWidth().semantics { liveRegion = LiveRegionMode.Polite }) {
        Row(Modifier.heightIn(min = 48.dp).padding(start = 14.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(text, color = fg, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f).padding(vertical = 8.dp))
            TextButton(onClick = onDismiss, modifier = Modifier.heightIn(min = 44.dp)) {
                Text(stringResource(R.string.msg_ok), color = act, fontWeight = FontWeight.Bold)
            }
        }
    }
}

/** Shown while the reader is higher up and something new arrived below: one tap goes to the newest text. */
@Composable
internal fun JumpChip(label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val candy = LocalCandy.current
    Surface(
        shape = CircleShape,
        color = candy.cta,
        shadowElevation = 6.dp,
        modifier = modifier.clip(CircleShape).clickable(role = Role.Button, onClick = onClick),
    ) {
        Row(
            Modifier.heightIn(min = 44.dp).padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Icon(Icons.Rounded.KeyboardArrowDown, contentDescription = null, tint = candy.onCta)
            Text(label, color = candy.onCta, style = MaterialTheme.typography.labelLarge)
        }
    }
}
